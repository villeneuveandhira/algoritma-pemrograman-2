system("cls");
            // printf("Add data for:\n");
            // printf("[1] 'Sutradara.dat'\n");
            // printf("[2] 'Genre.dat'\n");
            // printf("[3] 'Bioskop.dat'\n");
            // printf("[0] Exit\n");
            // ("=======================================================\n");
            // int add;
            // printf("Select Menu : ");
            // scanf("%d", &add);
            // switch (add) {
            //     case 1:
            //         break;

            //     case 2:
            //         break;

            //     case 3:
            //         break;

            //     default:
            //         break;
            // }